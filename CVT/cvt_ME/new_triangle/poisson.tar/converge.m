%
%  plots convergence history
%
A = load('converge');
[m,n] = size(A)

for i = 1:1:m
   iteration(i) = A(i,1);
   residual(i)  = A(i,2);
end

semilogy(iteration,residual);
xlabel('iteration');
ylabel('max(abs(residual))');
title('Multi-Grid Convergence History');
