function frame(filename,field,igrid,jgrid,iskip,jskip);
%
% contour plot template for vorticity or streamfunction
%
A = load (filename);
[m,n] = size(A)
if field == 2
   B = load('exact');
end

imax = igrid/iskip + 1;
jmax = jgrid/jskip + 1;

index = 0;
for j=1:1:jmax
   for i=1:1:imax
      index = jskip*(j-1)*(igrid+1) + iskip*(i-1) + 1;
      if field == 2
         Z(i,j) = B(index) - A(index);
      else
         Z(i,j) = A(index);
      end
   end
end

% surface plot

surfc(Z);
colormap cool;
if field == 1
   set(gca,'Zlim',[0.0,2.5],'View',[45.,15.]);
   title('Evolution of the Solution');
else
   set(gca,'Zlim',[-1.0,1.0]);
   title('Evolution of the Error');
end
