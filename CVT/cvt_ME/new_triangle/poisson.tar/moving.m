%
% contour plot movie
%
function frame(filename,field,igrid,jgrid,iskip,jskip)

%nstart = input(' Enter the starting frame? ')

fid = fopen('frames','r');
iv = fscanf(fid,'%d%d%d%d%d%d%d%d',8);

nstart = iv(1)
nend   = iv(2)
nstep  = iv(3)
field  = iv(4)
igrid  = iv(5)
jgrid  = iv(6)
iskip  = iv(7)
jskip  = iv(8)
fprintf('\n%d',nstart)
fprintf('\n%d',nend)
fprintf('\n%d',nstep)
fprintf('\n%d',field)
fprintf('\n%d',igrid)
fprintf('\n%d',jgrid)
fprintf('\n%d',iskip)
fprintf('\n%d',jskip)

ntimes = 4;
Mv = moviein(ntimes);

count = 0;
for k = nstart:nstep:nend

  count = count + 1;
  filename  = sprintf('%s%3.3d','CYCLE',k);
  fprintf('\n%s',filename);
  fid = fopen(filename,'r');
  fprintf('\n%d',fid);

  frame(filename,field,igrid,jgrid,iskip,jskip);

  Mv(count) = getframe;
  %saveas(gcf,filename,'jpg');

end;

% play the frames

fps = 6;
movie(Mv,ntimes,fps);
